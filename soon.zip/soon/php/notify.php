<?php
		$data = $_POST['email'];
		if(isset($data)) {
	
			$ret = file_put_contents('emails.txt', $data . "\n", FILE_APPEND);
	
			if($ret === false) {
				die('There was an error writing this file');
			}
			else {
				echo "Your Email :<br/>$data<br/>has been saved successfuly";
				}
		}
		else {
			   die('no post data to process');
			 }
?>
